package me.freo.bpmn;

import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;

@ProcessApplication("Coffee Approval Process")
public class CoffeeApprovalProcess extends ServletProcessApplication {
 // no impl required
	
}
