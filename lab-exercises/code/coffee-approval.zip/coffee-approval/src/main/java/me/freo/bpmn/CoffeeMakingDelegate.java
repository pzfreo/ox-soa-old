package me.freo.bpmn;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class CoffeeMakingDelegate implements JavaDelegate {
	private final static Logger LOGGER = Logger.getLogger("COFFEE-REQUESTS");

	public void execute(DelegateExecution de) throws Exception {

		LOGGER.info("Processing request by '" + de.getVariable("customerName"));
		LOGGER.info("Processing request for '" + de.getVariable("type"));
	}

}
