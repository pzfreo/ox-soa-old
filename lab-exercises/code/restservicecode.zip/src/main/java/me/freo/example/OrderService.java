package me.freo.example;

import java.net.URI;
import javax.ws.rs.Consumes;
//import javax.ws.rs.GET;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import org.json.JSONException;
import org.json.JSONObject;

@Path("/orders")
public class OrderService {
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/")
	public Response createURL(@Context UriInfo uri, String order) {
		String uuid = Order.createEntry(order);
		Response response = Response.created(URI.create("orders/" + uuid))
				.build();
		return response;
	}

	@javax.ws.rs.PUT
	@Path("/{uuid}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response placeOrder(@PathParam("uuid") String id, String order) {
		if (Order.updateEntry(id, order)) {
			return Response.ok().build();
		} else {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
	}

	@GET
	@Path("/")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getOrders(@Context UriInfo uri) {
		try {
			JSONObject json = Order.getOrders();
			return Response.ok().entity(json.toString()).build();
		} catch (JSONException e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();	
		}
	}

	@GET
	@Path("/{uuid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getOrder(@PathParam("uuid") String id) {
		try {
			JSONObject json = Order.getOrder(id);
			if (json==null) return Response.status(Status.GONE).build();
			else return Response.ok(json.toString()).build();
		}
		catch (NotFoundException nfe) {
			return Response.status(Status.NOT_FOUND).build();
		} catch (JSONException e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	@DELETE
	@Path("/{uuid}")
	public Response deleteOrder(@PathParam("uuid") String id) {
		if (Order.deleteOrder(id)) {
			return Response.ok().build();
		}
		else {
			return Response.status(Status.NOT_FOUND).build();
		}
		
	}

}
