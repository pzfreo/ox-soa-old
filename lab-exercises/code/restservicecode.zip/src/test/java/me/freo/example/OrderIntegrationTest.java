package me.freo.example;
import static org.junit.Assert.assertEquals;

import java.io.InputStream;


import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.jaxrs.client.WebClient;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.junit.BeforeClass;
import org.junit.Test;

public class OrderIntegrationTest {
	

	
		private static String endpointUrl;
		
		@BeforeClass
		public static void beforeClass() {
			endpointUrl = System.getProperty("service.url");
			System.out.println(endpointUrl);
		}
		
		@Test
		public void testGetOrders() throws Exception {
			WebClient client = WebClient.create(endpointUrl + "/orders");
			Response r = client.accept(MediaType.APPLICATION_JSON).get();
			assertEquals(Response.Status.OK.getStatusCode(), r.getStatus());
			String jsonString = IOUtils.toString((InputStream)r.getEntity());
			JSONObject json = new JSONObject((new JSONTokener(jsonString)));
			JSONArray jsonOrders = json.getJSONArray("orders");
			assert(jsonOrders!=null);
			assert(jsonOrders.length()>1);
			String href = jsonOrders.getJSONObject(1).getString("href");
			WebClient client2 = WebClient.create(endpointUrl + "/orders/"+href);
			Response r2 = client2.accept(MediaType.APPLICATION_JSON).get();
			assertEquals(Response.Status.OK.getStatusCode(), r2.getStatus());
			String jsonString2 = IOUtils.toString((InputStream)r2.getEntity());
			JSONObject json2 = new JSONObject((new JSONTokener(jsonString2)));
			assert(json2.getString("poNumber")!=null);
		}
		
		

}
