package me.freo.rest;

public class OrderService {


	  Order orderSingleton = null;
	  public OrderService() {
	    orderSingleton = Order.getInstance();
	  }


}
