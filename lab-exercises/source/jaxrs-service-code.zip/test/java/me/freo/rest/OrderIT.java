package me.freo.rest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import java.io.InputStream;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.jaxrs.client.WebClient;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.junit.BeforeClass;
import org.junit.Test;

public class OrderIT {

	private static String endpointUrl;

	@BeforeClass
	public static void beforeClass() {
		endpointUrl = System.getProperty("service.url");

	}

	@Test
	public void testGetOrders() throws Exception {
		WebClient client = WebClient.create(endpointUrl + "/orders");
		Response r = client.accept(MediaType.APPLICATION_JSON).get();
		assertEquals(Response.Status.OK.getStatusCode(), r.getStatus());
		String jsonString = IOUtils.toString((InputStream) r.getEntity());
		JSONObject json = new JSONObject((new JSONTokener(jsonString)));
		JSONArray jsonOrders = json.getJSONArray("orders");
		assertNotNull(jsonOrders);
		assert (jsonOrders.length() > 0);
		String href = jsonOrders.getJSONObject(0).getString("href");
		WebClient client2 = WebClient.create(endpointUrl + "/orders/" + href);
		Response r2 = client2.accept(MediaType.APPLICATION_JSON).get();
		assertEquals(Response.Status.OK.getStatusCode(), r2.getStatus());
		String jsonString2 = IOUtils.toString((InputStream) r2.getEntity());
		JSONObject json2 = new JSONObject((new JSONTokener(jsonString2)));
		assertNotNull(json2.getString("poNumber"));
		WebClient client3 = WebClient.create(endpointUrl + "/orders/blahblahblah" );
		Response r3 = client3.accept(MediaType.APPLICATION_JSON).get();
		assertEquals(Response.Status.NOT_FOUND.getStatusCode(), r3.getStatus());
		r3 = client3.accept(MediaType.APPLICATION_JSON).delete();
		assertEquals(Response.Status.NOT_FOUND.getStatusCode(), r3.getStatus());
		r3 = client3.type(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).put("{}");
		assertEquals(Response.Status.NOT_FOUND.getStatusCode(), r3.getStatus());
	}
	
	public void testPostAndPutOrder() throws Exception {
		WebClient client = WebClient.create(endpointUrl+"/orders/");
		String sampleJSON = ""
			+ "{'poNumber':'PO0002'," + "'lineItem':'22222',"
			+ "'quantity':'2'," + "'date':'12/12/2012',"
			+ "'customerNumber':'FREO0001'}";
		Response r = client.post(sampleJSON);
		assertEquals(Response.Status.CREATED.getStatusCode(), r.getStatus());
		assertNotNull(r.getLocation());
		WebClient client2 = WebClient.create(r.getLocation());
		Response r2 = client2.put(sampleJSON);
		assertEquals(Response.Status.OK.getStatusCode(), r2.getStatus());
		r2 = client2.accept(MediaType.APPLICATION_JSON).get();
		assertEquals(Response.Status.OK.getStatusCode(), r2.getStatus());
		String jsonString = IOUtils.toString((InputStream) r2.getEntity());
		JSONObject json = new JSONObject((new JSONTokener(jsonString)));
		assertEquals("PO0002",json.getString("poNumber"));
		r2 = client2.delete();
		assertEquals(Response.Status.OK.getStatusCode(), r2.getStatus());
		r2 = client2.accept(MediaType.APPLICATION_JSON).get();
		assertEquals(Response.Status.GONE.getStatusCode(), r2.getStatus());
	}
	

}
